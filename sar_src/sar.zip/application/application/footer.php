        
        </div>
        </div>
        <div id="footer">
        <div id="footer-inside">
        <p id="copyright">&copy; 2012 - <a href="um.ac.id">Universitas Negeri Malang</a></p>
        
        <!-- Please don't delete this. You can use this template for free and this is the only way that you can say thanks to me -->
          <p id="dont-delete-this">Design by <a href="http://www.davidkohout.cz">David Kohout</a> | Our tip: <a href="http://www.goodmood.cz" title="Absinthe, Becherovka, Slivovitz store">Absinthe Store</a></p>
        <!-- Thank you :) -->
        
        </div><div style="clear: both;"></div></div>
  </body>
</html>