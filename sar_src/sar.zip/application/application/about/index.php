<h3>Tentang Aplikasi ini</h3>

Aplikasi ini merupakan kegiatan pengabdian kepada masyarakat yang di danai oleh DIKTI tahun 2012 dengan melakukan kerjasama dengan TIM SAR Trenggana.<br />