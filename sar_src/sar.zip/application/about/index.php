<h3>Tentang Aplikasi ini</h3>

Aplikasi ini merupakan kegiatan pengabdian kepada masyarakat yang di danai oleh DIKTI tahun 2012 dengan melakukan kerjasama dengan TIM SAR Trenggana.<br /><br>
<h3>Kontak</h3>
Harits Ar Rosyid di <u>harits@ft.um.ac.id</u>
<br />